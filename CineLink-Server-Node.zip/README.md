# CineLink Server

Servidor Node.js de sinalização para o CineLink.

## Render
Build Command: npm install
Start Command: npm start

O servidor coordena salas, sinalização WebRTC e chat. Ele não hospeda filmes.
