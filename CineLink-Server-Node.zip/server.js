import express from "express";
import http from "http";
import cors from "cors";
import { Server } from "socket.io";

const app=express();
app.use(cors());
app.get("/",(req,res)=>res.json({name:"CineLink Signaling Server",status:"online"}));

const server=http.createServer(app);
const io=new Server(server,{cors:{origin:"*",methods:["GET","POST"]}});
const rooms=new Map();

io.on("connection",(socket)=>{
  socket.on("join-room",(roomId)=>{
    if(!roomId)return;
    const room=rooms.get(roomId)||new Set();
    if(room.size>=2){socket.emit("room-full");return;}
    room.add(socket.id);
    rooms.set(roomId,room);
    socket.data.roomId=roomId;
    socket.join(roomId);
    socket.emit("joined-room",{roomId,users:[...room].filter(id=>id!==socket.id)});
    socket.to(roomId).emit("peer-joined",{peerId:socket.id});
  });

  socket.on("signal",({target,data})=>{
    if(target)io.to(target).emit("signal",{sender:socket.id,data});
  });

  socket.on("room-message",(message)=>{
    const roomId=socket.data.roomId;
    if(roomId)socket.to(roomId).emit("room-message",{sender:socket.id,message});
  });

  socket.on("disconnect",()=>{
    const roomId=socket.data.roomId;
    const room=rooms.get(roomId);
    if(!room)return;
    room.delete(socket.id);
    socket.to(roomId).emit("peer-left",{peerId:socket.id});
    if(room.size===0)rooms.delete(roomId);
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,"0.0.0.0",()=>console.log("CineLink server online on port "+PORT));